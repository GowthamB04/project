package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Hospital;
import com.insurance.claimmanagement.repository.HospitalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class HospitalServiceImpl implements HospitalService {
    
    @Autowired
    private HospitalRepository hospitalRepository;
    
    @Override
    public Hospital saveHospital(Hospital hospital) {
        try {
            return hospitalRepository.save(hospital);
        } catch (Exception e) {
            throw new RuntimeException("Error saving hospital: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<Hospital> getHospitalById(Long hospitalId) {
        try {
            return hospitalRepository.findById(hospitalId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching hospital: " + e.getMessage());
        }
    }
    
    @Override
    public List<Hospital> getAllHospitals() {
        try {
            return hospitalRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all hospitals: " + e.getMessage());
        }
    }
    
    @Override
    public Hospital updateHospital(Hospital hospital) {
        try {
            Optional<Hospital> existingHospital = hospitalRepository.findById(hospital.getHospitalId());
            if (existingHospital.isPresent()) {
                return hospitalRepository.save(hospital);
            } else {
                throw new RuntimeException("Hospital not found with ID: " + hospital.getHospitalId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating hospital: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deleteHospital(Long hospitalId) {
        try {
            if (hospitalRepository.existsById(hospitalId)) {
                hospitalRepository.deleteById(hospitalId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting hospital: " + e.getMessage());
        }
    }
}

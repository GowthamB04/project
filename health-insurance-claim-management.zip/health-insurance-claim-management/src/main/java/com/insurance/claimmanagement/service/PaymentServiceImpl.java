package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Payment;
import com.insurance.claimmanagement.entity.Claim;
import com.insurance.claimmanagement.repository.PaymentRepository;
import com.insurance.claimmanagement.repository.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PaymentServiceImpl implements PaymentService {
    
    @Autowired
    private PaymentRepository paymentRepository;
    
    @Autowired
    private ClaimRepository claimRepository;
    
    @Override
    public Payment savePayment(Payment payment) {
        try {
            return paymentRepository.save(payment);
        } catch (Exception e) {
            throw new RuntimeException("Error saving payment: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<Payment> getPaymentById(Long paymentId) {
        try {
            return paymentRepository.findById(paymentId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching payment: " + e.getMessage());
        }
    }
    
    @Override
    public List<Payment> getAllPayments() {
        try {
            return paymentRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all payments: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<Payment> getPaymentByClaim(Claim claim) {
        try {
            return paymentRepository.findByClaim(claim);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching payment by claim: " + e.getMessage());
        }
    }
    
    @Override
    public List<Payment> getPaymentsByStatus(String status) {
        try {
            return paymentRepository.findByPaymentStatus(status);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching payments by status: " + e.getMessage());
        }
    }
    
    @Override
    public Payment updatePayment(Payment payment) {
        try {
            Optional<Payment> existingPayment = paymentRepository.findById(payment.getPaymentId());
            if (existingPayment.isPresent()) {
                return paymentRepository.save(payment);
            } else {
                throw new RuntimeException("Payment not found with ID: " + payment.getPaymentId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating payment: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deletePayment(Long paymentId) {
        try {
            if (paymentRepository.existsById(paymentId)) {
                paymentRepository.deleteById(paymentId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting payment: " + e.getMessage());
        }
    }
    
    @Override
    public Payment processPayment(Long paymentId) {
        try {
            Optional<Payment> paymentOptional = paymentRepository.findById(paymentId);
            if (paymentOptional.isPresent()) {
                Payment payment = paymentOptional.get();
                
                // Verify claim is approved
                Claim claim = payment.getClaim();
                if (!claim.getClaimStatus().equalsIgnoreCase("APPROVED")) {
                    throw new RuntimeException("Payment can only be processed for APPROVED claims");
                }
                
                payment.setPaymentStatus("COMPLETED");
                payment.setPaymentDate(LocalDate.now());
                
                // Update claim status to SETTLED
                claim.setClaimStatus("SETTLED");
                claimRepository.save(claim);
                
                return paymentRepository.save(payment);
            } else {
                throw new RuntimeException("Payment not found with ID: " + paymentId);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error processing payment: " + e.getMessage());
        }
    }
}

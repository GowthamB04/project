package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Claim;
import com.insurance.claimmanagement.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {
    Optional<Claim> findByClaimNumber(String claimNumber);
    List<Claim> findByUser(User user);
    List<Claim> findByClaimStatus(String status);
    List<Claim> findByAssignedApprover(User approver);
}

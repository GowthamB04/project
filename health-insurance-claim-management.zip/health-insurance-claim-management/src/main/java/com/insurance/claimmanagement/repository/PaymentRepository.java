package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Payment;
import com.insurance.claimmanagement.entity.Claim;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByClaim(Claim claim);
    List<Payment> findByPaymentStatus(String status);
}

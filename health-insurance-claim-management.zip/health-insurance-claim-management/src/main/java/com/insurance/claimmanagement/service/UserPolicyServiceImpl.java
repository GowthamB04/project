package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.UserPolicy;
import com.insurance.claimmanagement.entity.User;
import com.insurance.claimmanagement.repository.UserPolicyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserPolicyServiceImpl implements UserPolicyService {
    
    @Autowired
    private UserPolicyRepository userPolicyRepository;
    
    @Override
    public UserPolicy saveUserPolicy(UserPolicy userPolicy) {
        try {
            return userPolicyRepository.save(userPolicy);
        } catch (Exception e) {
            throw new RuntimeException("Error saving user policy: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<UserPolicy> getUserPolicyById(Long userPolicyId) {
        try {
            return userPolicyRepository.findById(userPolicyId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching user policy: " + e.getMessage());
        }
    }
    
    @Override
    public List<UserPolicy> getAllUserPolicies() {
        try {
            return userPolicyRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all user policies: " + e.getMessage());
        }
    }
    
    @Override
    public List<UserPolicy> getPoliciesByUser(User user) {
        try {
            return userPolicyRepository.findByUser(user);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching policies by user: " + e.getMessage());
        }
    }
    
    @Override
    public UserPolicy updateUserPolicy(UserPolicy userPolicy) {
        try {
            Optional<UserPolicy> existingUserPolicy = userPolicyRepository.findById(userPolicy.getUserPolicyId());
            if (existingUserPolicy.isPresent()) {
                return userPolicyRepository.save(userPolicy);
            } else {
                throw new RuntimeException("User policy not found with ID: " + userPolicy.getUserPolicyId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating user policy: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deleteUserPolicy(Long userPolicyId) {
        try {
            if (userPolicyRepository.existsById(userPolicyId)) {
                userPolicyRepository.deleteById(userPolicyId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting user policy: " + e.getMessage());
        }
    }
}

package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.InsurancePolicy;
import com.insurance.claimmanagement.repository.InsurancePolicyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class InsurancePolicyServiceImpl implements InsurancePolicyService {
    
    @Autowired
    private InsurancePolicyRepository policyRepository;
    
    @Override
    public InsurancePolicy savePolicy(InsurancePolicy policy) {
        try {
            policy.setUpdatedAt(LocalDateTime.now());
            return policyRepository.save(policy);
        } catch (Exception e) {
            throw new RuntimeException("Error saving policy: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<InsurancePolicy> getPolicyById(Long policyId) {
        try {
            return policyRepository.findById(policyId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching policy: " + e.getMessage());
        }
    }
    
    @Override
    public List<InsurancePolicy> getAllPolicies() {
        try {
            return policyRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all policies: " + e.getMessage());
        }
    }
    
    @Override
    public InsurancePolicy updatePolicy(InsurancePolicy policy) {
        try {
            Optional<InsurancePolicy> existingPolicy = policyRepository.findById(policy.getPolicyId());
            if (existingPolicy.isPresent()) {
                policy.setUpdatedAt(LocalDateTime.now());
                return policyRepository.save(policy);
            } else {
                throw new RuntimeException("Policy not found with ID: " + policy.getPolicyId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating policy: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deletePolicy(Long policyId) {
        try {
            if (policyRepository.existsById(policyId)) {
                policyRepository.deleteById(policyId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting policy: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<InsurancePolicy> getPolicyByNumber(String policyNumber) {
        try {
            return policyRepository.findByPolicyNumber(policyNumber);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching policy by number: " + e.getMessage());
        }
    }
}

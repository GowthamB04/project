package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.User;
import com.insurance.claimmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    
    @Override
    public User saveUser(User user) {
        try {
            // Hash the password before saving
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                user.setPassword(passwordEncoder.encode(user.getPassword()));
            }
            return userRepository.save(user);
        } catch (Exception e) {
            throw new RuntimeException("Error saving user: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<User> getUserById(Long userId) {
        try {
            return userRepository.findById(userId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching user: " + e.getMessage());
        }
    }
    
    @Override
    public List<User> getAllUsers() {
        try {
            return userRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all users: " + e.getMessage());
        }
    }
    
    @Override
    public List<User> getUsersByRole(String role) {
        try {
            return userRepository.findByRole(role);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching users by role: " + e.getMessage());
        }
    }
    
    @Override
    public User updateUser(User user) {
        try {
            Optional<User> existingUser = userRepository.findById(user.getUserId());
            if (existingUser.isPresent()) {
                User dbUser = existingUser.get();

                // Preserve existing password unless a new one is provided
                if (user.getPassword() == null || user.getPassword().isEmpty()) {
                    user.setPassword(dbUser.getPassword());
                } else {
                    user.setPassword(passwordEncoder.encode(user.getPassword()));
                }

                return userRepository.save(user);
            } else {
                throw new RuntimeException("User not found with ID: " + user.getUserId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating user: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deleteUser(Long userId) {
        try {
            if (userRepository.existsById(userId)) {
                userRepository.deleteById(userId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting user: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<User> validateLogin(String username, String password) {
        try {
            String inputUsername = username != null ? username.trim() : null;
            String inputPassword = password != null ? password.trim() : null;

            if (inputUsername == null || inputUsername.isEmpty() || inputPassword == null || inputPassword.isEmpty()) {
                return Optional.empty();
            }

            Optional<User> user = userRepository.findByUsername(inputUsername);

            if (!user.isPresent()) {
                // Fallback for username case or whitespace mismatch
                for (User u : userRepository.findAll()) {
                    if (u.getUsername() != null && u.getUsername().trim().equalsIgnoreCase(inputUsername)) {
                        user = Optional.of(u);
                        break;
                    }
                }
            }

            if (user.isPresent()) {
                User foundUser = user.get();

                // Check account status
                if (foundUser.getAccountStatus() == null ||
                    foundUser.getAccountStatus().trim().equalsIgnoreCase("INACTIVE")) {
                    return Optional.empty();
                }

                String storedPassword = foundUser.getPassword();
                if (storedPassword == null) {
                    return Optional.empty();
                }

                storedPassword = storedPassword.trim();
                boolean passwordMatched = false;

                // If stored password is a BCrypt hash, verify it; otherwise compare plain text.
                if (storedPassword.startsWith("$2a$") || storedPassword.startsWith("$2b$") || storedPassword.startsWith("$2y$")) {
                    try {
                        passwordMatched = passwordEncoder.matches(inputPassword, storedPassword);
                    } catch (Exception e) {
                        passwordMatched = false;
                    }
                } else {
                    passwordMatched = inputPassword.equals(storedPassword);
                }

                if (passwordMatched) {
                    foundUser.setLastLogin(LocalDateTime.now());
                    userRepository.save(foundUser);
                    return Optional.of(foundUser);
                }
            }

            return Optional.empty();
        } catch (Exception e) {
            throw new RuntimeException("Error validating login: " + e.getMessage());
        }
    }
}


package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.User;
import com.insurance.claimmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    
    @Override
    public User saveUser(User user) {
        try {
            // Hash the password before saving
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                user.setPassword(passwordEncoder.encode(user.getPassword()));
            }
            return userRepository.save(user);
        } catch (Exception e) {
            throw new RuntimeException("Error saving user: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<User> getUserById(Long userId) {
        try {
            return userRepository.findById(userId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching user: " + e.getMessage());
        }
    }
    
    @Override
    public List<User> getAllUsers() {
        try {
            return userRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all users: " + e.getMessage());
        }
    }
    
    @Override
    public List<User> getUsersByRole(String role) {
        try {
            return userRepository.findByRole(role);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching users by role: " + e.getMessage());
        }
    }
    
    @Override
    public User updateUser(User user) {
        try {
            Optional<User> existingUser = userRepository.findById(user.getUserId());
            if (existingUser.isPresent()) {
                // Don't update password here unless explicitly provided
                return userRepository.save(user);
            } else {
                throw new RuntimeException("User not found with ID: " + user.getUserId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating user: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deleteUser(Long userId) {
        try {
            if (userRepository.existsById(userId)) {
                userRepository.deleteById(userId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting user: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<User> validateLogin(String username, String password) {
    try {
        Optional<User> user = userRepository.findByUsername(username);

        if (user.isPresent()) {

            User foundUser = user.get();

            // Check account status
            if (foundUser.getAccountStatus() == null ||
                foundUser.getAccountStatus().equalsIgnoreCase("INACTIVE")) {

                return Optional.empty();
            }

            boolean passwordMatched = false;

            // Check BCrypt encrypted password
            try {
                passwordMatched = passwordEncoder.matches(password, foundUser.getPassword());
            } catch (Exception e) {
                passwordMatched = false;
            }

            // Also support plain text passwords for SQL inserted users
            if (!passwordMatched) {
                passwordMatched = password.equals(foundUser.getPassword());
            }

            if (passwordMatched) {

                foundUser.setLastLogin(LocalDateTime.now());

                userRepository.save(foundUser);

                return Optional.of(foundUser);
            }
        }

        return Optional.empty();

    } catch (Exception e) {
        throw new RuntimeException("Error validating login: " + e.getMessage());
    }
}
}

package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Claim;
import com.insurance.claimmanagement.entity.User;
import com.insurance.claimmanagement.repository.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ClaimServiceImpl implements ClaimService {
    
    @Autowired
    private ClaimRepository claimRepository;
    
    @Override
    public Claim saveClaim(Claim claim) {
        try {
            // Set default status if not provided
            if (claim.getClaimStatus() == null || claim.getClaimStatus().isEmpty()) {
                claim.setClaimStatus("PENDING");
            }
            // Set claim date if not provided
            if (claim.getClaimDate() == null) {
                claim.setClaimDate(LocalDate.now());
            }
            return claimRepository.save(claim);
        } catch (Exception e) {
            throw new RuntimeException("Error saving claim: " + e.getMessage());
        }
    }
    
    @Override
    public Optional<Claim> getClaimById(Long claimId) {
        try {
            return claimRepository.findById(claimId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching claim: " + e.getMessage());
        }
    }
    
    @Override
    public List<Claim> getAllClaims() {
        try {
            return claimRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all claims: " + e.getMessage());
        }
    }
    
    @Override
    public List<Claim> getClaimsByUser(User user) {
        try {
            return claimRepository.findByUser(user);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching claims by user: " + e.getMessage());
        }
    }
    
    @Override
    public List<Claim> getClaimsByStatus(String status) {
        try {
            return claimRepository.findByClaimStatus(status);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching claims by status: " + e.getMessage());
        }
    }
    
    @Override
    public List<Claim> getClaimsByApprover(User approver) {
        try {
            return claimRepository.findByAssignedApprover(approver);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching claims by approver: " + e.getMessage());
        }
    }
    
    @Override
    public Claim updateClaim(Claim claim) {
        try {
            Optional<Claim> existingClaim = claimRepository.findById(claim.getClaimId());
            if (existingClaim.isPresent()) {
                return claimRepository.save(claim);
            } else {
                throw new RuntimeException("Claim not found with ID: " + claim.getClaimId());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating claim: " + e.getMessage());
        }
    }
    
    @Override
    public boolean deleteClaim(Long claimId) {
        try {
            if (claimRepository.existsById(claimId)) {
                claimRepository.deleteById(claimId);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error deleting claim: " + e.getMessage());
        }
    }
    
    @Override
    public Claim approveClaim(Long claimId, Double approvedAmount, String approverComment) {
        try {
            Optional<Claim> claimOptional = claimRepository.findById(claimId);
            if (claimOptional.isPresent()) {
                Claim claim = claimOptional.get();
                claim.setClaimStatus("APPROVED");
                claim.setApprovedAmount(approvedAmount);
                claim.setApprovedDate(LocalDate.now());
                
                // If approved amount < claim amount, comment is mandatory
                if (approvedAmount < claim.getClaimAmount()) {
                    if (approverComment == null || approverComment.isEmpty()) {
                        throw new RuntimeException("Approver comment is mandatory when approved amount is less than claim amount");
                    }
                    claim.setApproverComment(approverComment);
                }
                
                return claimRepository.save(claim);
            } else {
                throw new RuntimeException("Claim not found with ID: " + claimId);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error approving claim: " + e.getMessage());
        }
    }
    
    @Override
    public Claim rejectClaim(Long claimId, String rejectionReason) {
        try {
            Optional<Claim> claimOptional = claimRepository.findById(claimId);
            if (claimOptional.isPresent()) {
                // Rejection reason is mandatory
                if (rejectionReason == null || rejectionReason.isEmpty()) {
                    throw new RuntimeException("Rejection reason is mandatory");
                }
                
                Claim claim = claimOptional.get();
                claim.setClaimStatus("REJECTED");
                claim.setRejectionReason(rejectionReason);
                claim.setApprovedDate(LocalDate.now());
                
                return claimRepository.save(claim);
            } else {
                throw new RuntimeException("Claim not found with ID: " + claimId);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error rejecting claim: " + e.getMessage());
        }
    }
}

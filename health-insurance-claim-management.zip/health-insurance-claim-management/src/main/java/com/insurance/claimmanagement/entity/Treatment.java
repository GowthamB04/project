package com.insurance.claimmanagement.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "treatments")
public class Treatment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long treatmentId;
    
    @Column(nullable = false, length = 100)
    private String diagnosis;
    
    @Column(nullable = false, columnDefinition = "TEXT")
    private String treatmentDescription;
    
    @Column(nullable = false)
    private Double treatmentAmount;
    
    @Column(nullable = false)
    private LocalDate treatmentDate;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference("user-treatment")
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id", nullable = false)
    @JsonBackReference("doctor-treatment")
    private Doctor doctor;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hospital_id", nullable = false)
    @JsonBackReference("hospital-treatment")
    private Hospital hospital;
    
    // One Treatment has One Claim
    @OneToOne(mappedBy = "treatment", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("treatment-claim")
    private Claim claim;
    
    // Constructor
    public Treatment() {
    }
    
    public Treatment(String diagnosis, String treatmentDescription, Double treatmentAmount,
                    LocalDate treatmentDate, User user, Doctor doctor, Hospital hospital) {
        this.diagnosis = diagnosis;
        this.treatmentDescription = treatmentDescription;
        this.treatmentAmount = treatmentAmount;
        this.treatmentDate = treatmentDate;
        this.user = user;
        this.doctor = doctor;
        this.hospital = hospital;
    }
    
    // Getters and Setters
    public Long getTreatmentId() {
        return treatmentId;
    }
    
    public void setTreatmentId(Long treatmentId) {
        this.treatmentId = treatmentId;
    }
    
    public String getDiagnosis() {
        return diagnosis;
    }
    
    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }
    
    public String getTreatmentDescription() {
        return treatmentDescription;
    }
    
    public void setTreatmentDescription(String treatmentDescription) {
        this.treatmentDescription = treatmentDescription;
    }
    
    public Double getTreatmentAmount() {
        return treatmentAmount;
    }
    
    public void setTreatmentAmount(Double treatmentAmount) {
        this.treatmentAmount = treatmentAmount;
    }
    
    public LocalDate getTreatmentDate() {
        return treatmentDate;
    }
    
    public void setTreatmentDate(LocalDate treatmentDate) {
        this.treatmentDate = treatmentDate;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
    
    public Hospital getHospital() {
        return hospital;
    }
    
    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }
    
    public Claim getClaim() {
        return claim;
    }
    
    public void setClaim(Claim claim) {
        this.claim = claim;
    }
    
    @Override
    public String toString() {
        return "Treatment{" +
                "treatmentId=" + treatmentId +
                ", diagnosis='" + diagnosis + '\'' +
                ", treatmentAmount=" + treatmentAmount +
                ", treatmentDate=" + treatmentDate +
                '}';
    }
}

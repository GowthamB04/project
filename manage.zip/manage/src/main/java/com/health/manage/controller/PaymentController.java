package com.health.manage.controller;

import com.health.manage.entity.Payment;
import com.health.manage.service.PaymentService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    private final PaymentService service;

    public PaymentController(PaymentService service) { this.service = service; }

    @PostMapping
    public Payment processPayment(@RequestBody Payment payment) { return service.processPayment(payment); }

    @GetMapping
    public List<Payment> listPayments() { return service.listPayments(); }
}

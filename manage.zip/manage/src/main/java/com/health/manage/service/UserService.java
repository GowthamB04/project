package com.health.manage.service;

import com.health.manage.entity.User;
import com.health.manage.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
    private final UserRepository repo;

    public UserService(UserRepository repo) { this.repo = repo; }

    public User login(String username, String password) {
        User user = repo.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            user.setLastLogin(java.time.LocalDate.now());
            return repo.save(user);
        }
        return null;
    }

    public List<User> listUsers() { return repo.findAll(); }

    public void deleteUser(Long id) { repo.deleteById(id); }
}

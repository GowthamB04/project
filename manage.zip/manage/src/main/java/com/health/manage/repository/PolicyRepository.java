package com.health.manage.repository;

import com.health.manage.entity.InsurancePolicy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PolicyRepository extends JpaRepository<InsurancePolicy, Long> {
    InsurancePolicy findByPolicyNumber(String policyNumber);
}

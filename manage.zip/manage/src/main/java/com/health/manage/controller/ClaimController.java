package com.health.manage.controller;

import com.health.manage.entity.Claim;
import com.health.manage.service.ClaimService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/claims")
public class ClaimController {
    private final ClaimService service;

    public ClaimController(ClaimService service) { this.service = service; }

    @PostMapping
    public Claim createClaim(@RequestBody Claim claim) { return service.createClaim(claim); }

    @GetMapping
    public List<Claim> listClaims() { return service.listClaims(); }

    @PutMapping("/{id}/status")
    public Claim updateStatus(@PathVariable Long id, @RequestParam String status) {
        return service.updateClaimStatus(id, status);
    }

    @DeleteMapping("/{id}")
    public String deleteClaim(@PathVariable Long id) {
        service.deleteClaim(id);
        return "Claim deleted successfully";
    }
}

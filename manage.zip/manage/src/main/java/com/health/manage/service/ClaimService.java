package com.health.manage.service;

import com.health.manage.entity.Claim;
import com.health.manage.repository.ClaimRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ClaimService {
    private final ClaimRepository repo;

    public ClaimService(ClaimRepository repo) { this.repo = repo; }

    public Claim createClaim(Claim claim) { return repo.save(claim); }

    public List<Claim> listClaims() { return repo.findAll(); }

    public Claim updateClaimStatus(Long id, String status) {
        Claim claim = repo.findById(id).orElse(null);
        if (claim != null) {
            claim.setClaimStatus(status);
            return repo.save(claim);
        }
        return null;
    }

    public void deleteClaim(Long id) { repo.deleteById(id); }
}

package com.health.manage.controller;

import com.health.manage.entity.Hospital;
import com.health.manage.service.HospitalService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/hospitals")
public class HospitalController {
    private final HospitalService service;

    public HospitalController(HospitalService service) { this.service = service; }

    @PostMapping
    public Hospital createHospital(@RequestBody Hospital hospital) { return service.createHospital(hospital); }

    @GetMapping
    public List<Hospital> listHospitals() { return service.listHospitals(); }

    @DeleteMapping("/{id}")
    public String deleteHospital(@PathVariable Long id) {
        service.deleteHospital(id);
        return "Hospital deleted successfully";
    }
}

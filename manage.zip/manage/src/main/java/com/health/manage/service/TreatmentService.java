package com.health.manage.service;

import com.health.manage.entity.Treatment;
import com.health.manage.repository.TreatmentRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TreatmentService {
    private final TreatmentRepository repo;

    public TreatmentService(TreatmentRepository repo) { this.repo = repo; }

    public Treatment createTreatment(Treatment treatment) { return repo.save(treatment); }

    public List<Treatment> listTreatments() { return repo.findAll(); }

    public void deleteTreatment(Long id) { repo.deleteById(id); }
}

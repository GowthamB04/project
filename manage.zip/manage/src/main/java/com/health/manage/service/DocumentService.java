package com.health.manage.service;

import com.health.manage.entity.Document;
import com.health.manage.repository.DocumentRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DocumentService {
    private final DocumentRepository repo;

    public DocumentService(DocumentRepository repo) { this.repo = repo; }

    public Document uploadDocument(Document document) { return repo.save(document); }

    public List<Document> listDocuments() { return repo.findAll(); }

    public void deleteDocument(Long id) { repo.deleteById(id); }
}

package com.health.manage.controller;

import com.health.manage.entity.Doctor;
import com.health.manage.service.DoctorService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/doctors")
public class DoctorController {
    private final DoctorService service;

    public DoctorController(DoctorService service) { this.service = service; }

    @PostMapping
    public Doctor createDoctor(@RequestBody Doctor doctor) { return service.createDoctor(doctor); }

    @GetMapping
    public List<Doctor> listDoctors() { return service.listDoctors(); }

    @DeleteMapping("/{id}")
    public String deleteDoctor(@PathVariable Long id) {
        service.deleteDoctor(id);
        return "Doctor deleted successfully";
    }
}

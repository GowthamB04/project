package com.health.manage.service;

import com.health.manage.entity.Hospital;
import com.health.manage.repository.HospitalRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class HospitalService {
    private final HospitalRepository repo;

    public HospitalService(HospitalRepository repo) { this.repo = repo; }

    public Hospital createHospital(Hospital hospital) { return repo.save(hospital); }

    public List<Hospital> listHospitals() { return repo.findAll(); }

    public void deleteHospital(Long id) { repo.deleteById(id); }
}

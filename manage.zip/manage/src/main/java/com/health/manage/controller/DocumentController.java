package com.health.manage.controller;

import com.health.manage.entity.Document;
import com.health.manage.service.DocumentService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/documents")
public class DocumentController {
    private final DocumentService service;

    public DocumentController(DocumentService service) { this.service = service; }

    @PostMapping
    public Document uploadDocument(@RequestBody Document document) { return service.uploadDocument(document); }

    @GetMapping
    public List<Document> listDocuments() { return service.listDocuments(); }

    @DeleteMapping("/{id}")
    public String deleteDocument(@PathVariable Long id) {
        service.deleteDocument(id);
        return "Document deleted successfully";
    }
}

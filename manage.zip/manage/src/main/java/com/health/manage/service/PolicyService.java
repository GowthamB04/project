package com.health.manage.service;

import com.health.manage.entity.InsurancePolicy;
import com.health.manage.repository.PolicyRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PolicyService {
    private final PolicyRepository repo;

    public PolicyService(PolicyRepository repo) { this.repo = repo; }

    public InsurancePolicy createPolicy(InsurancePolicy policy) { return repo.save(policy); }

    public List<InsurancePolicy> listPolicies() { return repo.findAll(); }

    public InsurancePolicy getPolicyById(Long id) { return repo.findById(id).orElse(null); }

    public InsurancePolicy updatePolicy(Long id, InsurancePolicy policy) {
        policy.setPolicyId(id);
        return repo.save(policy);
    }

    public void deletePolicy(Long id) { repo.deleteById(id); }
}

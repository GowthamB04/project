package com.health.manage.controller;

import com.health.manage.entity.InsurancePolicy;
import com.health.manage.service.PolicyService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/policies")
public class PolicyController {
    private final PolicyService service;

    public PolicyController(PolicyService service) { this.service = service; }

    @PostMapping
    public InsurancePolicy createPolicy(@RequestBody InsurancePolicy policy) { return service.createPolicy(policy); }

    @GetMapping
    public List<InsurancePolicy> listPolicies() { return service.listPolicies(); }

    @GetMapping("/{id}")
    public InsurancePolicy getPolicy(@PathVariable Long id) { return service.getPolicyById(id); }

    @PutMapping("/{id}")
    public InsurancePolicy updatePolicy(@PathVariable Long id, @RequestBody InsurancePolicy policy) {
        return service.updatePolicy(id, policy);
    }

    @DeleteMapping("/{id}")
    public String deletePolicy(@PathVariable Long id) {
        service.deletePolicy(id);
        return "Policy deleted successfully";
    }
}

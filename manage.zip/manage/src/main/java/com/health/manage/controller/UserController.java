package com.health.manage.controller;


import com.health.manage.entity.User;
import com.health.manage.service.UserService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    private final UserService service;

    public UserController(UserService service) {
        this.service = service;
    }

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        User loggedIn = service.login(user.getUsername(), user.getPassword());
        return loggedIn != null ? "Login successful for " + loggedIn.getRole()
                                : "Login failed";
    }

    @GetMapping
    public List<User> listUsers() {
        return service.listUsers();
    }
}

package com.health.manage.controller;

import com.health.manage.entity.Treatment;
import com.health.manage.service.TreatmentService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/treatments")
public class TreatmentController {
    private final TreatmentService service;

    public TreatmentController(TreatmentService service) { this.service = service; }

    @PostMapping
    public Treatment createTreatment(@RequestBody Treatment treatment) { return service.createTreatment(treatment); }

    @GetMapping
    public List<Treatment> listTreatments() { return service.listTreatments(); }

    @DeleteMapping("/{id}")
    public String deleteTreatment(@PathVariable Long id) {
        service.deleteTreatment(id);
        return "Treatment deleted successfully";
    }
}

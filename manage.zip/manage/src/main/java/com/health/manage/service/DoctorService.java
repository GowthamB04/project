package com.health.manage.service;

import com.health.manage.entity.Doctor;
import com.health.manage.repository.DoctorRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DoctorService {
    private final DoctorRepository repo;

    public DoctorService(DoctorRepository repo) { this.repo = repo; }

    public Doctor createDoctor(Doctor doctor) { return repo.save(doctor); }

    public List<Doctor> listDoctors() { return repo.findAll(); }

    public void deleteDoctor(Long id) { repo.deleteById(id); }
}

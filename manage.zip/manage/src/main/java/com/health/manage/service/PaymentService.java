package com.health.manage.service;

import com.health.manage.entity.Payment;
import com.health.manage.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PaymentService {
    private final PaymentRepository repo;

    public PaymentService(PaymentRepository repo) { this.repo = repo; }

    public Payment processPayment(Payment payment) { return repo.save(payment); }

    public List<Payment> listPayments() { return repo.findAll(); }
}

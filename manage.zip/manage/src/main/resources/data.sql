INSERT INTO user (username, email, password, phone_number, role, account_status, created_at, last_login)
VALUES ('DSR', 'admin@gmail.com', 'Admin@123', '7092363234', 'Client', 'ACTIVE', '2025-05-19', '2026-05-15');

INSERT INTO user (username, email, password, phone_number, role, account_status, created_at, last_login)
VALUES ('RAM', 'manager@gmail.com', 'Manager@123', '9876543210', 'Admin', 'ACTIVE', '2025-05-19', '2026-05-15');

package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.entity.Payment;
import com.insurance.claimmanagement.repository.PaymentRepository;
import com.insurance.claimmanagement.service.PaymentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;

    public PaymentServiceImpl(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public Optional<Payment> getPaymentById(Long id) {
        return paymentRepository.findById(id);
    }

    @Override
    public Payment savePayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Override
    public Payment updatePayment(Long id, Payment payment) {
        Payment existingPayment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id " + id));
        existingPayment.setPaymentAmount(payment.getPaymentAmount());
        existingPayment.setPaymentDate(payment.getPaymentDate());
        existingPayment.setPaymentMode(payment.getPaymentMode());
        existingPayment.setTransactionId(payment.getTransactionId());
        existingPayment.setPaymentStatus(payment.getPaymentStatus());
        existingPayment.setClaim(payment.getClaim());
        existingPayment.setUser(payment.getUser());
        return paymentRepository.save(existingPayment);
    }

    @Override
    public void deletePayment(Long id) {
        paymentRepository.deleteById(id);
    }
}

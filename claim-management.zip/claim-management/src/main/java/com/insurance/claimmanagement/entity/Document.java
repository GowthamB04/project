package com.insurance.claimmanagement.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "documents")
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    @Column(nullable = false)
    private String documentName;

    private String documentType;

    private String documentPath;

    private LocalDate uploadedDate;

    @ManyToOne
    @JoinColumn(name = "claim_id")
    @JsonBackReference(value = "claim-documents")
    private Claim claim;

    public Document() {
    }

    public Document(Long documentId, String documentName, String documentType, String documentPath,
                    LocalDate uploadedDate, Claim claim) {
        this.documentId = documentId;
        this.documentName = documentName;
        this.documentType = documentType;
        this.documentPath = documentPath;
        this.uploadedDate = uploadedDate;
        this.claim = claim;
    }

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentPath() {
        return documentPath;
    }

    public void setDocumentPath(String documentPath) {
        this.documentPath = documentPath;
    }

    public LocalDate getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(LocalDate uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public Claim getClaim() {
        return claim;
    }

    public void setClaim(Claim claim) {
        this.claim = claim;
    }

    @Override
    public String toString() {
        return "Document{" +
                "documentId=" + documentId +
                ", documentName='" + documentName + '\'' +
                ", documentType='" + documentType + '\'' +
                ", documentPath='" + documentPath + '\'' +
                ", uploadedDate=" + uploadedDate +
                '}';
    }
}

package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsernameAndPasswordAndAccountStatus(String username, String password, String accountStatus);
    Optional<User> findByUsername(String username);
}

package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRepository extends JpaRepository<Company, Long> {
}

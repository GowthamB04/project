package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.entity.Document;
import com.insurance.claimmanagement.repository.DocumentRepository;
import com.insurance.claimmanagement.service.DocumentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;

    public DocumentServiceImpl(DocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    @Override
    public List<Document> getAllDocuments() {
        return documentRepository.findAll();
    }

    @Override
    public Optional<Document> getDocumentById(Long id) {
        return documentRepository.findById(id);
    }

    @Override
    public Document saveDocument(Document document) {
        return documentRepository.save(document);
    }

    @Override
    public Document updateDocument(Long id, Document document) {
        Document existingDocument = documentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Document not found with id " + id));
        existingDocument.setDocumentName(document.getDocumentName());
        existingDocument.setDocumentType(document.getDocumentType());
        existingDocument.setDocumentPath(document.getDocumentPath());
        existingDocument.setUploadedDate(document.getUploadedDate());
        existingDocument.setClaim(document.getClaim());
        return documentRepository.save(existingDocument);
    }

    @Override
    public void deleteDocument(Long id) {
        documentRepository.deleteById(id);
    }
}

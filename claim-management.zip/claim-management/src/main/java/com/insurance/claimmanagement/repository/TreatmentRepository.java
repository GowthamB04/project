package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Treatment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TreatmentRepository extends JpaRepository<Treatment, Long> {
}

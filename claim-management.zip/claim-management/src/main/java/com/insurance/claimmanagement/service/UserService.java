package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.User;
import java.util.List;
import java.util.Optional;

public interface UserService {
    List<User> getAllUsers();
    List<User> getAllUsers(String accessRole, Long claimId);
    Optional<User> getUserById(Long id);
    Optional<User> getUserById(Long id, String accessRole, Long claimId);
    User saveUser(User user);
    User updateUser(Long id, User user);
    void deleteUser(Long id);
    Optional<User> authenticate(String username, String password);
}

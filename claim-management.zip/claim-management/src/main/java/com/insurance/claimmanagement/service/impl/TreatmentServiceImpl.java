package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.entity.Treatment;
import com.insurance.claimmanagement.repository.TreatmentRepository;
import com.insurance.claimmanagement.service.TreatmentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TreatmentServiceImpl implements TreatmentService {

    private final TreatmentRepository treatmentRepository;

    public TreatmentServiceImpl(TreatmentRepository treatmentRepository) {
        this.treatmentRepository = treatmentRepository;
    }

    @Override
    public List<Treatment> getAllTreatments() {
        return treatmentRepository.findAll();
    }

    @Override
    public Optional<Treatment> getTreatmentById(Long id) {
        return treatmentRepository.findById(id);
    }

    @Override
    public Treatment saveTreatment(Treatment treatment) {
        return treatmentRepository.save(treatment);
    }

    @Override
    public Treatment updateTreatment(Long id, Treatment treatment) {
        Treatment existingTreatment = treatmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Treatment not found with id " + id));
        existingTreatment.setDiagnosis(treatment.getDiagnosis());
        existingTreatment.setTreatmentDescription(treatment.getTreatmentDescription());
        existingTreatment.setTreatmentAmount(treatment.getTreatmentAmount());
        existingTreatment.setTreatmentDate(treatment.getTreatmentDate());
        existingTreatment.setUser(treatment.getUser());
        existingTreatment.setDoctor(treatment.getDoctor());
        existingTreatment.setHospital(treatment.getHospital());
        return treatmentRepository.save(existingTreatment);
    }

    @Override
    public void deleteTreatment(Long id) {
        treatmentRepository.deleteById(id);
    }
}

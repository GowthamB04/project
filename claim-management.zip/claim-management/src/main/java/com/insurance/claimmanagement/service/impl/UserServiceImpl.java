package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.entity.Claim;
import com.insurance.claimmanagement.entity.User;
import com.insurance.claimmanagement.repository.ClaimRepository;
import com.insurance.claimmanagement.repository.UserRepository;
import com.insurance.claimmanagement.service.UserService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ClaimRepository claimRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, ClaimRepository claimRepository) {
        this.userRepository = userRepository;
        this.claimRepository = claimRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public List<User> getAllUsers(String accessRole, Long claimId) {
        if ("ADMIN".equalsIgnoreCase(accessRole)) {
            return userRepository.findAll();
        }
        if ("APPROVER".equalsIgnoreCase(accessRole) && claimId != null) {
            return claimRepository.findById(claimId)
                    .map(claim -> List.of(claim.getUser()))
                    .orElse(List.of());
        }
        return List.of();
    }

    @Override
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public Optional<User> getUserById(Long id, String accessRole, Long claimId) {
        if ("ADMIN".equalsIgnoreCase(accessRole)) {
            return userRepository.findById(id);
        }
        if ("APPROVER".equalsIgnoreCase(accessRole) && claimId != null) {
            return claimRepository.findById(claimId)
                    .map(Claim::getUser)
                    .filter(user -> user.getUserId().equals(id));
        }
        if ("POLICYHOLDER".equalsIgnoreCase(accessRole)) {
            return userRepository.findById(id);
        }
        return Optional.empty();
    }

    @Override
    public User saveUser(User user) {
        if (user.getPassword() != null && !isPasswordEncoded(user.getPassword())) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Long id, User user) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id " + id));
        existingUser.setUsername(user.getUsername());
        existingUser.setFullName(user.getFullName());
        if (user.getPassword() != null && !user.getPassword().isBlank()) {
            existingUser.setPassword(isPasswordEncoded(user.getPassword())
                    ? user.getPassword()
                    : passwordEncoder.encode(user.getPassword()));
        }
        existingUser.setEmail(user.getEmail());
        existingUser.setPhoneNumber(user.getPhoneNumber());
        existingUser.setDateOfBirth(user.getDateOfBirth());
        existingUser.setAddress(user.getAddress());
        existingUser.setAccountNumber(user.getAccountNumber());
        existingUser.setIfscCode(user.getIfscCode());
        existingUser.setBankName(user.getBankName());
        existingUser.setCompany(user.getCompany());
        existingUser.setRole(user.getRole());
        existingUser.setAccountStatus(user.getAccountStatus());
        existingUser.setCreatedAt(user.getCreatedAt());
        existingUser.setLastLogin(user.getLastLogin());
        return userRepository.save(existingUser);
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public Optional<User> authenticate(String username, String password) {
        return userRepository.findByUsername(username)
                .filter(user -> "ACTIVE".equalsIgnoreCase(user.getAccountStatus()))
                .filter(user -> password != null && passwordEncoder.matches(password, user.getPassword()));
    }

    private boolean isPasswordEncoded(String password) {
        return password != null && (password.startsWith("$2a$") || password.startsWith("$2b$") || password.startsWith("$2y$"));
    }
}

package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.entity.Hospital;
import com.insurance.claimmanagement.repository.HospitalRepository;
import com.insurance.claimmanagement.service.HospitalService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HospitalServiceImpl implements HospitalService {

    private final HospitalRepository hospitalRepository;

    public HospitalServiceImpl(HospitalRepository hospitalRepository) {
        this.hospitalRepository = hospitalRepository;
    }

    @Override
    public List<Hospital> getAllHospitals() {
        return hospitalRepository.findAll();
    }

    @Override
    public Optional<Hospital> getHospitalById(Long id) {
        return hospitalRepository.findById(id);
    }

    @Override
    public Hospital saveHospital(Hospital hospital) {
        return hospitalRepository.save(hospital);
    }

    @Override
    public Hospital updateHospital(Long id, Hospital hospital) {
        Hospital existingHospital = hospitalRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Hospital not found with id " + id));
        existingHospital.setHospitalName(hospital.getHospitalName());
        existingHospital.setHospitalType(hospital.getHospitalType());
        existingHospital.setAddress(hospital.getAddress());
        existingHospital.setPhoneNumber(hospital.getPhoneNumber());
        return hospitalRepository.save(existingHospital);
    }

    @Override
    public void deleteHospital(Long id) {
        hospitalRepository.deleteById(id);
    }
}

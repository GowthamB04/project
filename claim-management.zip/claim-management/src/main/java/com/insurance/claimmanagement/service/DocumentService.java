package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Document;
import java.util.List;
import java.util.Optional;

public interface DocumentService {
    List<Document> getAllDocuments();
    Optional<Document> getDocumentById(Long id);
    Document saveDocument(Document document);
    Document updateDocument(Long id, Document document);
    void deleteDocument(Long id);
}

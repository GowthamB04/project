package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HospitalRepository extends JpaRepository<Hospital, Long> {
}

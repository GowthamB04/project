package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Treatment;
import java.util.List;
import java.util.Optional;

public interface TreatmentService {
    List<Treatment> getAllTreatments();
    Optional<Treatment> getTreatmentById(Long id);
    Treatment saveTreatment(Treatment treatment);
    Treatment updateTreatment(Long id, Treatment treatment);
    void deleteTreatment(Long id);
}

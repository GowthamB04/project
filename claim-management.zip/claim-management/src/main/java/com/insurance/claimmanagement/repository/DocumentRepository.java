package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentRepository extends JpaRepository<Document, Long> {
}

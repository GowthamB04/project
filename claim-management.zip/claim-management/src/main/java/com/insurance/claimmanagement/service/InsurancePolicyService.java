package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.InsurancePolicy;
import java.util.List;
import java.util.Optional;

public interface InsurancePolicyService {
    List<InsurancePolicy> getAllPolicies();
    Optional<InsurancePolicy> getPolicyById(Long id);
    InsurancePolicy savePolicy(InsurancePolicy policy);
    InsurancePolicy updatePolicy(Long id, InsurancePolicy policy);
    void deletePolicy(Long id);
}

package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.entity.InsurancePolicy;
import com.insurance.claimmanagement.repository.InsurancePolicyRepository;
import com.insurance.claimmanagement.service.InsurancePolicyService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    private final InsurancePolicyRepository policyRepository;

    public InsurancePolicyServiceImpl(InsurancePolicyRepository policyRepository) {
        this.policyRepository = policyRepository;
    }

    @Override
    public List<InsurancePolicy> getAllPolicies() {
        return policyRepository.findAll();
    }

    @Override
    public Optional<InsurancePolicy> getPolicyById(Long id) {
        return policyRepository.findById(id);
    }

    @Override
    public InsurancePolicy savePolicy(InsurancePolicy policy) {
        return policyRepository.save(policy);
    }

    @Override
    public InsurancePolicy updatePolicy(Long id, InsurancePolicy policy) {
        InsurancePolicy existingPolicy = policyRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Policy not found with id " + id));
        existingPolicy.setPolicyNumber(policy.getPolicyNumber());
        existingPolicy.setPolicyName(policy.getPolicyName());
        existingPolicy.setPolicyType(policy.getPolicyType());
        existingPolicy.setCoverageAmount(policy.getCoverageAmount());
        existingPolicy.setPremiumAmount(policy.getPremiumAmount());
        existingPolicy.setBenefits(policy.getBenefits());
        existingPolicy.setPolicyStatus(policy.getPolicyStatus());
        existingPolicy.setStartDate(policy.getStartDate());
        existingPolicy.setEndDate(policy.getEndDate());
        existingPolicy.setCreatedAt(policy.getCreatedAt());
        existingPolicy.setUpdatedAt(policy.getUpdatedAt());
        return policyRepository.save(existingPolicy);
    }

    @Override
    public void deletePolicy(Long id) {
        policyRepository.deleteById(id);
    }
}

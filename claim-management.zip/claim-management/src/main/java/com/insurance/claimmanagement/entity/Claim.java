package com.insurance.claimmanagement.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "claims")
public class Claim {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long claimId;

    @Column(nullable = false, unique = true)
    private String claimNumber;

    private Double claimAmount;

    private Double approvedAmount;

    private String claimStatus;

    @Column(length = 1000)
    private String approverComment;

    @Column(length = 1000)
    private String rejectionReason;

    private LocalDate claimDate;

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-claims")
    private User user;

    @ManyToOne
    @JoinColumn(name = "policy_id")
    @JsonBackReference(value = "policy-claims")
    private InsurancePolicy insurancePolicy;

    @OneToOne
    @JoinColumn(name = "treatment_id")
    @JsonManagedReference(value = "treatment-claim")
    private Treatment treatment;

    @ManyToOne
    @JoinColumn(name = "assigned_to_id")
    private User assignedTo;

    @ManyToOne
    @JoinColumn(name = "approved_by_id")
    @JsonBackReference(value = "user-approved-claims")
    private User approvedBy;

    private LocalDateTime approvedDate;

    @OneToMany(mappedBy = "claim", cascade = CascadeType.ALL)
    @JsonManagedReference(value = "claim-documents")
    private List<Document> documents = new ArrayList<>();

    @OneToOne(mappedBy = "claim", cascade = CascadeType.ALL)
    @JsonManagedReference(value = "claim-payment")
    private Payment payment;

    public Claim() {
    }

    public Claim(Long claimId, String claimNumber, Double claimAmount, Double approvedAmount, String claimStatus,
                 String approverComment, String rejectionReason, LocalDate claimDate, User user,
                 InsurancePolicy insurancePolicy, Treatment treatment, User assignedTo, User approvedBy,
                 LocalDateTime approvedDate) {
        this.claimId = claimId;
        this.claimNumber = claimNumber;
        this.claimAmount = claimAmount;
        this.approvedAmount = approvedAmount;
        this.claimStatus = claimStatus;
        this.approverComment = approverComment;
        this.rejectionReason = rejectionReason;
        this.claimDate = claimDate;
        this.user = user;
        this.insurancePolicy = insurancePolicy;
        this.treatment = treatment;
        this.assignedTo = assignedTo;
        this.approvedBy = approvedBy;
        this.approvedDate = approvedDate;
    }

    public Long getClaimId() {
        return claimId;
    }

    public void setClaimId(Long claimId) {
        this.claimId = claimId;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public Double getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(Double claimAmount) {
        this.claimAmount = claimAmount;
    }

    public Double getApprovedAmount() {
        return approvedAmount;
    }

    public void setApprovedAmount(Double approvedAmount) {
        this.approvedAmount = approvedAmount;
    }

    public String getClaimStatus() {
        return claimStatus;
    }

    public void setClaimStatus(String claimStatus) {
        this.claimStatus = claimStatus;
    }

    public String getApproverComment() {
        return approverComment;
    }

    public void setApproverComment(String approverComment) {
        this.approverComment = approverComment;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public LocalDate getClaimDate() {
        return claimDate;
    }

    public void setClaimDate(LocalDate claimDate) {
        this.claimDate = claimDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public InsurancePolicy getInsurancePolicy() {
        return insurancePolicy;
    }

    public void setInsurancePolicy(InsurancePolicy insurancePolicy) {
        this.insurancePolicy = insurancePolicy;
    }

    public Treatment getTreatment() {
        return treatment;
    }

    public void setTreatment(Treatment treatment) {
        this.treatment = treatment;
    }

    public User getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(User assignedTo) {
        this.assignedTo = assignedTo;
    }

    public User getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(User approvedBy) {
        this.approvedBy = approvedBy;
    }

    public LocalDateTime getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(LocalDateTime approvedDate) {
        this.approvedDate = approvedDate;
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    @Override
    public String toString() {
        return "Claim{" +
                "claimId=" + claimId +
                ", claimNumber='" + claimNumber + '\'' +
                ", claimAmount=" + claimAmount +
                ", approvedAmount=" + approvedAmount +
                ", claimStatus='" + claimStatus + '\'' +
                ", approverComment='" + approverComment + '\'' +
                ", rejectionReason='" + rejectionReason + '\'' +
                ", claimDate=" + claimDate +
                ", approvedDate=" + approvedDate +
                '}';
    }
}

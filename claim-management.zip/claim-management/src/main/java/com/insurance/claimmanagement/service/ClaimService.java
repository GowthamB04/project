package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Claim;
import java.util.List;
import java.util.Optional;

public interface ClaimService {
    List<Claim> getAllClaims();
    Optional<Claim> getClaimById(Long id);
    Claim saveClaim(Claim claim);
    Claim updateClaim(Long id, Claim claim);
    Claim approveClaim(Long claimId, com.insurance.claimmanagement.dto.ClaimApprovalRequest approvalRequest);
    void deleteClaim(Long id);
}

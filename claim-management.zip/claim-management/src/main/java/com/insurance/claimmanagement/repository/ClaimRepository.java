package com.insurance.claimmanagement.repository;

import com.insurance.claimmanagement.entity.Claim;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClaimRepository extends JpaRepository<Claim, Long> {
}

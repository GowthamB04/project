package com.insurance.claimmanagement.service;

import com.insurance.claimmanagement.entity.Hospital;
import java.util.List;
import java.util.Optional;

public interface HospitalService {
    List<Hospital> getAllHospitals();
    Optional<Hospital> getHospitalById(Long id);
    Hospital saveHospital(Hospital hospital);
    Hospital updateHospital(Long id, Hospital hospital);
    void deleteHospital(Long id);
}

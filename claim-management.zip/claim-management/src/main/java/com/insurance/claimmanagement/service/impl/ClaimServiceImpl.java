package com.insurance.claimmanagement.service.impl;

import com.insurance.claimmanagement.dto.ClaimApprovalRequest;
import com.insurance.claimmanagement.entity.Claim;
import com.insurance.claimmanagement.entity.Payment;
import com.insurance.claimmanagement.entity.User;
import com.insurance.claimmanagement.repository.ClaimRepository;
import com.insurance.claimmanagement.repository.UserRepository;
import com.insurance.claimmanagement.service.ClaimService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ClaimServiceImpl implements ClaimService {

    private final ClaimRepository claimRepository;
    private final UserRepository userRepository;

    public ClaimServiceImpl(ClaimRepository claimRepository, UserRepository userRepository) {
        this.claimRepository = claimRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }

    @Override
    public Optional<Claim> getClaimById(Long id) {
        return claimRepository.findById(id);
    }

    @Override
    public Claim saveClaim(Claim claim) {
        return claimRepository.save(claim);
    }

    @Override
    public Claim updateClaim(Long id, Claim claim) {
        Claim existingClaim = claimRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Claim not found with id " + id));
        existingClaim.setClaimNumber(claim.getClaimNumber());
        existingClaim.setClaimAmount(claim.getClaimAmount());
        existingClaim.setApprovedAmount(claim.getApprovedAmount());
        existingClaim.setClaimStatus(claim.getClaimStatus());
        existingClaim.setApproverComment(claim.getApproverComment());
        existingClaim.setRejectionReason(claim.getRejectionReason());
        existingClaim.setClaimDate(claim.getClaimDate());
        existingClaim.setUser(claim.getUser());
        existingClaim.setInsurancePolicy(claim.getInsurancePolicy());
        existingClaim.setTreatment(claim.getTreatment());
        existingClaim.setAssignedTo(claim.getAssignedTo());
        existingClaim.setApprovedBy(claim.getApprovedBy());
        existingClaim.setApprovedDate(claim.getApprovedDate());
        return claimRepository.save(existingClaim);
    }

    @Override
    public Claim approveClaim(Long claimId, ClaimApprovalRequest approvalRequest) {
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new RuntimeException("Claim not found with id " + claimId));

        User approver = userRepository.findById(approvalRequest.getApproverId())
                .orElseThrow(() -> new RuntimeException("Approver not found with id " + approvalRequest.getApproverId()));

        if (!"APPROVER".equalsIgnoreCase(approver.getRole()) && !"ADMIN".equalsIgnoreCase(approver.getRole())) {
            throw new RuntimeException("Only APPROVER or ADMIN can approve the claim");
        }

        double approvedAmount = approvalRequest.getApprovedAmount() != null
                ? approvalRequest.getApprovedAmount()
                : (claim.getClaimAmount() != null ? claim.getClaimAmount() : 0.0);

        claim.setApprovedAmount(approvedAmount);
        claim.setClaimStatus("APPROVED");
        claim.setApproverComment(approvalRequest.getApproverComment());
        claim.setApprovedBy(approver);
        claim.setAssignedTo(approver);
        claim.setApprovedDate(LocalDateTime.now());

        Payment payment = new Payment();
        payment.setPaymentAmount(approvedAmount);
        payment.setPaymentDate(LocalDateTime.now());
        payment.setPaymentMode(approvalRequest.getPaymentMode());
        payment.setTransactionId(approvalRequest.getTransactionId());
        payment.setPaymentStatus("COMPLETED");
        payment.setClaim(claim);
        payment.setUser(claim.getUser());
        payment.setCompany(approver.getCompany());

        claim.setPayment(payment);
        return claimRepository.save(claim);
    }

    @Override
    public void deleteClaim(Long id) {
        claimRepository.deleteById(id);
    }
}

package com.insurance.claimmanagement.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "treatments")
public class Treatment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long treatmentId;

    private String diagnosis;

    @Column(length = 1000)
    private String treatmentDescription;

    private Double treatmentAmount;

    private LocalDate treatmentDate;

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-treatments")
    private User user;

    @ManyToOne
    @JoinColumn(name = "doctor_id")
    @JsonBackReference(value = "doctor-treatments")
    private Doctor doctor;

    @ManyToOne
    @JoinColumn(name = "hospital_id")
    @JsonBackReference(value = "hospital-treatments")
    private Hospital hospital;

    @OneToOne(mappedBy = "treatment")
    @JsonBackReference(value = "treatment-claim")
    private Claim claim;

    public Treatment() {
    }

    public Treatment(Long treatmentId, String diagnosis, String treatmentDescription, Double treatmentAmount,
                     LocalDate treatmentDate, User user, Doctor doctor, Hospital hospital) {
        this.treatmentId = treatmentId;
        this.diagnosis = diagnosis;
        this.treatmentDescription = treatmentDescription;
        this.treatmentAmount = treatmentAmount;
        this.treatmentDate = treatmentDate;
        this.user = user;
        this.doctor = doctor;
        this.hospital = hospital;
    }

    public Long getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(Long treatmentId) {
        this.treatmentId = treatmentId;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getTreatmentDescription() {
        return treatmentDescription;
    }

    public void setTreatmentDescription(String treatmentDescription) {
        this.treatmentDescription = treatmentDescription;
    }

    public Double getTreatmentAmount() {
        return treatmentAmount;
    }

    public void setTreatmentAmount(Double treatmentAmount) {
        this.treatmentAmount = treatmentAmount;
    }

    public LocalDate getTreatmentDate() {
        return treatmentDate;
    }

    public void setTreatmentDate(LocalDate treatmentDate) {
        this.treatmentDate = treatmentDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public Claim getClaim() {
        return claim;
    }

    public void setClaim(Claim claim) {
        this.claim = claim;
    }

    @Override
    public String toString() {
        return "Treatment{" +
                "treatmentId=" + treatmentId +
                ", diagnosis='" + diagnosis + '\'' +
                ", treatmentDescription='" + treatmentDescription + '\'' +
                ", treatmentAmount=" + treatmentAmount +
                ", treatmentDate=" + treatmentDate +
                '}';
    }
}

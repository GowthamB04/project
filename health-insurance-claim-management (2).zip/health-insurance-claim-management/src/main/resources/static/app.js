const apiBase = '/api';
let currentUser = null;

const ROLE_CONFIG = {
    ADMIN: {
        tabs: ['btnDashboard', 'btnPolicies', 'btnClaims', 'btnUsers', 'btnProfile', 'btnLogout'],
        subtitle: 'Admin Dashboard - Manage all system data'
    },
    APPROVER: {
        tabs: ['btnDashboard', 'btnApprovals', 'btnProfile', 'btnLogout'],
        subtitle: 'Approver Dashboard - Review and approve claims'
    },
    POLICYHOLDER: {
        tabs: ['btnDashboard', 'btnClaims', 'btnPolicies', 'btnProfile', 'btnLogout'],
        subtitle: 'Policyholder Dashboard - File and track claims'
    }
};

function setAuthenticationState(isAuthenticated) {
    const navBar = document.querySelector('.nav-bar');
    const headerSubtitle = document.getElementById('headerSubtitle');
    
    if (isAuthenticated) {
        navBar.classList.remove('hide');
        const config = ROLE_CONFIG[currentUser.role] || ROLE_CONFIG.POLICYHOLDER;
        headerSubtitle.textContent = config.subtitle;
        
        // Show role-specific tabs
        document.querySelectorAll('.nav-btn').forEach(btn => {
            const isInConfig = config.tabs.includes(btn.id);
            btn.classList.toggle('hide', !isInConfig);
        });
    } else {
        navBar.classList.add('hide');
        headerSubtitle.textContent = 'Login to access the dashboard and manage claims.';
        document.querySelectorAll('.nav-btn').forEach((btn) => btn.classList.remove('active'));
    }
}

function showSection(sectionId) {
    if (!currentUser && sectionId !== 'loginSection') {
        showMessage('Please login first to access the application.', 'error');
        sectionId = 'loginSection';
    }
    document.querySelectorAll('main section').forEach((section) => section.classList.add('hide'));
    document.getElementById(sectionId).classList.remove('hide');
    document.querySelectorAll('.nav-btn').forEach((btn) => btn.classList.remove('active'));
    
    const activeButton = {
        dashboardSection: 'btnDashboard',
        policiesSection: 'btnPolicies',
        claimsSection: 'btnClaims',
        approvalsSection: 'btnApprovals',
        usersSection: 'btnUsers',
        profileSection: 'btnProfile'
    }[sectionId];
    if (activeButton) {
        document.getElementById(activeButton)?.classList.add('active');
    }
    if (sectionId === 'dashboardSection') {
        renderDashboard();
    }
    if (sectionId === 'profileSection') {
        renderProfile();
    }
}

function showMessage(message, type = 'success') {
    const messageBox = document.getElementById('messageSection');
    messageBox.textContent = message;
    messageBox.className = `message-box ${type}`;
    messageBox.classList.remove('hide');
    setTimeout(() => messageBox.classList.add('hide'), 5000);
}

async function loginUser() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    if (!username || !password) {
        showMessage('Username and password are required.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/users/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const responseText = await response.text();
        console.log('Backend response:', responseText);
        
        let payload;
        try {
            payload = JSON.parse(responseText);
        } catch (jsonError) {
            showMessage(`Login error: Invalid response from server. Check console for details.`, 'error');
            console.error('JSON Parse error:', jsonError);
            console.error('Raw response text:', responseText.substring(0, 500));
            return;
        }
        
        if (payload.status) {
            currentUser = payload.data;
            setAuthenticationState(true);
            showMessage(`Welcome ${currentUser.fullName} (${currentUser.role})`, 'success');
            showSection('dashboardSection');
        } else {
            showMessage(payload.message || 'Login failed', 'error');
        }
    } catch (error) {
        showMessage(`Login error: ${error.message}`, 'error');
        console.error('Login error:', error);
    }
}

function logout() {
    currentUser = null;
    setAuthenticationState(false);
    showSection('loginSection');
    showMessage('You have been logged out.', 'success');
}

function renderDashboard() {
    const dashboard = document.getElementById('dashboardContent');
    if (!currentUser) {
        dashboard.innerHTML = '<p>Please login to see your dashboard.</p>';
        return;
    }

    const role = currentUser.role;
    let dashboardHTML = '';

    if (role === 'ADMIN') {
        dashboardHTML = `
            <div class="dashboard-grid">
                <div class="info-card">
                    <h3>Admin Overview</h3>
                    <p>Manage users, policies, and all claims in the system.</p>
                    <button class="secondary-btn" onclick="showSection('usersSection'); loadUsers();">View All Users</button>
                </div>
                <div class="info-card">
                    <h3>Quick Actions</h3>
                    <ul>
                        <li><a onclick="showSection('policiesSection'); loadPolicies();">View Insurance Policies</a></li>
                        <li><a onclick="showSection('claimsSection'); loadClaims();">View All Claims</a></li>
                        <li><a onclick="showSection('profileSection');">View Your Profile</a></li>
                    </ul>
                </div>
            </div>
        `;
    } else if (role === 'APPROVER') {
        dashboardHTML = `
            <div class="dashboard-grid">
                <div class="info-card">
                    <h3>Approver Dashboard</h3>
                    <p>Review and approve pending insurance claims.</p>
                    <button class="primary-btn" onclick="showSection('approvalsSection'); loadPendingClaims();">Review Pending Claims</button>
                </div>
                <div class="info-card">
                    <h3>Your Profile</h3>
                    <p><strong>Name:</strong> ${currentUser.fullName}</p>
                    <p><strong>Role:</strong> ${currentUser.role}</p>
                    <button class="secondary-btn" onclick="showSection('profileSection');">View Full Profile</button>
                </div>
            </div>
        `;
    } else if (role === 'POLICYHOLDER') {
        dashboardHTML = `
            <div class="dashboard-grid">
                <div class="info-card">
                    <h3>File a Claim</h3>
                    <p>Submit insurance claims for your treatments.</p>
                    <button class="primary-btn" onclick="showSection('claimsSection'); setTimeout(() => document.getElementById('createClaimForm').classList.remove('hide'), 100);">File New Claim</button>
                </div>
                <div class="info-card">
                    <h3>My Claims & Policies</h3>
                    <ul>
                        <li><a onclick="showSection('claimsSection'); loadClaims();">View My Claims</a></li>
                        <li><a onclick="showSection('policiesSection'); loadMyPolicies();">View My Policies</a></li>
                        <li><a onclick="showSection('profileSection');">View My Profile</a></li>
                    </ul>
                </div>
            </div>
        `;
    }

    dashboard.innerHTML = dashboardHTML;
}

function renderProfile() {
    if (!currentUser) return;
    
    document.getElementById('profileName').textContent = currentUser.fullName || 'N/A';
    document.getElementById('profileEmail').textContent = currentUser.email || 'N/A';
    document.getElementById('profileUsername').textContent = currentUser.username || 'N/A';
    document.getElementById('profileRole').textContent = currentUser.role || 'N/A';
    document.getElementById('profilePhone').textContent = currentUser.phoneNumber || 'N/A';
    document.getElementById('profileStatus').textContent = currentUser.accountStatus || 'N/A';
    document.getElementById('profileDOB').textContent = currentUser.dateOfBirth || 'N/A';
    document.getElementById('profileAddress').textContent = currentUser.address || 'N/A';
}

async function loadPolicies() {
    if (!currentUser) {
        showMessage('Please login to load policies.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/policies`);
        const payload = await response.json();
        if (payload.status) {
            const tbody = document.querySelector('#policiesTable tbody');
            tbody.innerHTML = payload.data.map(policy => `
                <tr>
                    <td>${policy.policyId}</td>
                    <td>${policy.policyNumber || ''}</td>
                    <td>${policy.policyName || ''}</td>
                    <td>${policy.policyType || ''}</td>
                    <td>$${policy.coverageAmount ?? ''}</td>
                    <td>$${policy.premiumAmount ?? ''}</td>
                    <td>${policy.policyStatus || ''}</td>
                    <td>${policy.startDate || ''} - ${policy.endDate || ''}</td>
                </tr>
            `).join('');
            showSection('policiesSection');
        } else {
            showMessage(payload.message || 'Unable to fetch policies.', 'error');
        }
    } catch (error) {
        showMessage(`Error loading policies: ${error.message}`, 'error');
    }
}

async function loadMyPolicies() {
    if (!currentUser || currentUser.role !== 'POLICYHOLDER') {
        showMessage('Only policyholders can view their policies.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/user-policies/user/${currentUser.userId}`);
        const payload = await response.json();
        if (payload.status) {
            const tbody = document.querySelector('#policiesTable tbody');
            tbody.innerHTML = payload.data.map(userPolicy => {
                const policy = userPolicy.insurancePolicy || {};
                return `
                    <tr>
                        <td>${policy.policyId || ''}</td>
                        <td>${policy.policyNumber || ''}</td>
                        <td>${policy.policyName || ''}</td>
                        <td>${policy.policyType || ''}</td>
                        <td>$${policy.coverageAmount ?? ''}</td>
                        <td>$${policy.premiumAmount ?? ''}</td>
                        <td>${userPolicy.status || policy.policyStatus || ''}</td>
                        <td>${userPolicy.agreementDate || ''} - ${userPolicy.expiryDate || ''}</td>
                    </tr>
                `;
            }).join('');
            showSection('policiesSection');
        } else {
            showMessage(payload.message || 'Unable to fetch your policies.', 'error');
        }
    } catch (error) {
        showMessage(`Error loading policies: ${error.message}`, 'error');
    }
}

async function loadClaims() {
    if (!currentUser) {
        showMessage('Please login to load claims.', 'error');
        return;
    }

    let url = `${apiBase}/claims`;
    if (currentUser.role === 'POLICYHOLDER') {
        url = `${apiBase}/claims/user/${currentUser.userId}`;
        document.getElementById('createClaimForm').classList.remove('hide');
    } else if (currentUser.role === 'ADMIN') {
        document.getElementById('createClaimForm').classList.add('hide');
    }

    try {
        const response = await fetch(url);
        const payload = await response.json();
        if (payload.status) {
            const tbody = document.querySelector('#claimsTable tbody');
            tbody.innerHTML = payload.data.map(claim => `
                <tr>
                    <td>${claim.claimId}</td>
                    <td>${claim.claimNumber || ''}</td>
                    <td>$${claim.claimAmount ?? ''}</td>
                    <td><span class="status-badge status-${claim.claimStatus?.toLowerCase()}">${claim.claimStatus || 'N/A'}</span></td>
                    <td>${claim.insurancePolicy?.policyName || claim.insurancePolicy?.policyNumber || ''}</td>
                    <td>${claim.claimDate || ''}</td>
                    <td>${claim.claimStatus === 'PENDING' ? '<span class="info">Awaiting Approval</span>' : ''}</td>
                </tr>
            `).join('');
            showSection('claimsSection');
        } else {
            showMessage(payload.message || 'Unable to fetch claims.', 'error');
        }
    } catch (error) {
        showMessage(`Error loading claims: ${error.message}`, 'error');
    }
}

async function loadPendingClaims() {
    if (!currentUser || currentUser.role !== 'APPROVER') {
        showMessage('Only approvers can view pending claims.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/claims/status/PENDING`);
        const payload = await response.json();
        if (payload.status) {
            const tbody = document.querySelector('#approvalsTable tbody');
            tbody.innerHTML = payload.data.map(claim => `
                <tr>
                    <td>${claim.claimId}</td>
                    <td>${claim.claimNumber || ''}</td>
                    <td>$${claim.claimAmount ?? ''}</td>
                    <td>${claim.user?.fullName || claim.user?.username || ''}</td>
                    <td>${claim.insurancePolicy?.policyName || claim.insurancePolicy?.policyNumber || ''}</td>
                    <td>${claim.claimDate || ''}</td>
                    <td><span class="status-badge status-pending">PENDING</span></td>
                </tr>
            `).join('');
            showSection('approvalsSection');
        } else {
            showMessage(payload.message || 'Unable to fetch pending claims.', 'error');
        }
    } catch (error) {
        showMessage(`Error loading pending claims: ${error.message}`, 'error');
    }
}

async function approveClaim() {
    const claimId = document.getElementById('approveClaimId').value;
    const approvedAmount = document.getElementById('approveAmount').value;
    const approverComment = document.getElementById('approveComment').value.trim();
    if (!claimId || !approvedAmount || !approverComment) {
        showMessage('Complete all approval fields before submitting.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/claims/${claimId}/approve`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ approvedAmount: parseFloat(approvedAmount), approverComment })
        });
        const payload = await response.json();
        if (payload.status) {
            showMessage(payload.message || 'Claim approved successfully.');
            document.getElementById('approveClaimId').value = '';
            document.getElementById('approveAmount').value = '';
            document.getElementById('approveComment').value = '';
            loadPendingClaims();
        } else {
            showMessage(payload.message || 'Approval failed.', 'error');
        }
    } catch (error) {
        showMessage(`Error approving claim: ${error.message}`, 'error');
    }
}

async function rejectClaim() {
    const claimId = document.getElementById('rejectClaimId').value;
    const rejectionReason = document.getElementById('rejectReason').value.trim();
    if (!claimId || !rejectionReason) {
        showMessage('Complete all rejection fields before submitting.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/claims/${claimId}/reject`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rejectionReason })
        });
        const payload = await response.json();
        if (payload.status) {
            showMessage(payload.message || 'Claim rejected successfully.');
            document.getElementById('rejectClaimId').value = '';
            document.getElementById('rejectReason').value = '';
            loadPendingClaims();
        } else {
            showMessage(payload.message || 'Rejection failed.', 'error');
        }
    } catch (error) {
        showMessage(`Error rejecting claim: ${error.message}`, 'error');
    }
}

async function createNewClaim() {
    if (currentUser.role !== 'POLICYHOLDER') {
        showMessage('Only policyholders can file claims.', 'error');
        return;
    }

    const claimAmount = document.getElementById('newClaimAmount').value;
    const policyId = document.getElementById('newClaimPolicyId').value;
    const treatmentId = document.getElementById('newClaimTreatmentId').value;

    if (!claimAmount || !policyId || !treatmentId) {
        showMessage('All fields are required to file a claim.', 'error');
        return;
    }

    try {
        const claimNumber = 'CLM-' + Date.now();
        const response = await fetch(`${apiBase}/claims`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                claimNumber: claimNumber,
                claimAmount: parseFloat(claimAmount),
                claimStatus: 'PENDING',
                user: { userId: currentUser.userId },
                treatment: { treatmentId: parseInt(treatmentId) },
                insurancePolicy: { policyId: parseInt(policyId) }
            })
        });
        const payload = await response.json();
        if (payload.status) {
            showMessage(payload.message || 'Claim filed successfully.');
            document.getElementById('newClaimAmount').value = '';
            document.getElementById('newClaimPolicyId').value = '';
            document.getElementById('newClaimTreatmentId').value = '';
            loadClaims();
        } else {
            showMessage(payload.message || 'Failed to file claim.', 'error');
        }
    } catch (error) {
        showMessage(`Error filing claim: ${error.message}`, 'error');
    }
}

async function loadUsers() {
    if (!currentUser || currentUser.role !== 'ADMIN') {
        showMessage('Only ADMIN users can load all users.', 'error');
        return;
    }

    try {
        const response = await fetch(`${apiBase}/users`);
        const payload = await response.json();
        if (payload.status) {
            const tbody = document.querySelector('#usersTable tbody');
            tbody.innerHTML = payload.data.map(user => `
                <tr>
                    <td>${user.userId}</td>
                    <td>${user.fullName || ''}</td>
                    <td>${user.username || ''}</td>
                    <td>${user.email || ''}</td>
                    <td>${user.role || ''}</td>
                    <td><span class="status-badge status-${user.accountStatus?.toLowerCase()}">${user.accountStatus || 'N/A'}</span></td>
                </tr>
            `).join('');
            showSection('usersSection');
        } else {
            showMessage(payload.message || 'Unable to fetch users.', 'error');
        }
    } catch (error) {
        showMessage(`Error loading users: ${error.message}`, 'error');
    }
}

setAuthenticationState(false);
showSection('loginSection');
